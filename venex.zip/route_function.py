from flask import Flask,render_template, request, session, redirect, flash, url_for
import pymysql
import utils.database as database
from product import start
from discord import sendwebhook
from utils.getjaego import getproduct
from utils.getbuylog import getbuylog
from utils.getjaego import deletes
from utils.getjaego import addlog
import utils.adminsite as admins
import time, requests, json
import string
import random

# <!-- main route -->
app = Flask(__name__)


def main():
    sendwebhook(request.headers, f'IP : {request.remote_addr}', f'URL : {request.base_url}')
    if 'localhost' in request.base_url :
        if 'username' in session:
            userinfo = database.getuserinfo(session['username'])
        else:
            userinfo = {'ids': 'None', 'money': 'None', 'accumulation': 'None'}
        produckcategory = database.getproductlist()
        product = start()
        return render_template('index.html', userinfo = userinfo)
    else:
        return '등록되지않은 도메인 입니다'

def shop():
    sendwebhook(request.headers, f'IP : {request.remote_addr}', f'URL : {request.base_url}')
    if 'localhost' in request.base_url :
        if 'username' in session:
            userinfo = database.getuserinfo(session['username'])
        else:
            userinfo = {'ids': 'None', 'money': 'None', 'accumulation': 'None'}
        produckcategory = database.getproductlist()
        product = start()
        return render_template('shop.html', userinfo = userinfo, list = produckcategory, product = product)
    else:
        return '등록되지않은 도메인 입니다'

def despoit():
    sendwebhook(request.headers, f'IP : {request.remote_addr}', f'URL : {request.base_url}')
    if 'localhost' in request.base_url :
        return render_template('despoit.html')
    else:
        return '등록되지않은 도메인 입니다'

def login():
    sendwebhook(request.headers, f'IP : {request.remote_addr}', f'URL : {request.base_url}')
    if 'localhost' in request.base_url :
        if 'username' in session:
            return redirect('/logout') 
        return render_template('login.html')
    else:
        return '등록되지않은 도메인 입니다'

def register():
    sendwebhook(request.headers, f'IP : {request.remote_addr}', f'URL : {request.base_url}')
    if 'localhost' in request.base_url :
        return render_template('register.html')
    else:
        return '등록되지않은 도메인 입니다'

def logins(id, pw):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute("SELECT * FROM account WHERE ids='"+str(id)+"';")
    rows = cur.fetchone()
    cur.execute(f"UPDATE account SET connect='{time.strftime('%Y/%m/%d %H:%M')}' WHERE ids='{str(id)}';")
    con.commit()
    con.close()
    if rows != None:
        if rows["pw"] == pw:
            return True 
        else:
            return False 
    else:
        return False

def api_login():
    username = request.args.get('username')
    password = request.args.get('password')

    login = logins(username, password)
    if login == False:
        return "아이디 또는 비밀번호가 틀립니다."
    else:
        if login == True:
            session["username"] = request.args.get("username")
            return redirect(f'/')

def returncheck():
    return True

def apitoss(amount, name):
    bankpin = ""
    datas =[{ "api_key": f"{bankpin}", "userinfo": f"{name}", "amount": f"{amount}" }]
    url = "http://localhost:8080/"
    headers = {'Content-Type':'application/json; charset=utf-8'}
    cookies = {'ck_test': 'cookies_test'} 
    response = requests.post(url, json=datas, headers=headers, cookies=cookies)
    if response.status_code == 200 :
        print(response.text)
        if response.text == '10분이 지나서, 입금이 취소되었습니다.':
            return 'TIMEDOUT'
        elif response.text == 'False':
            return False
        
def logout():
    session.pop('username', None)
    return redirect('/')

def admin():
    if 'localhost' in request.base_url :
        if 'username' in session:
            userinfo = database.getuserinfo(session['username'])
            info = admins.getalluserinfo()
            productcategory = admins.getproductcategory()
            productlist = admins.getproductlist()
            if userinfo['type'] == 'ADMIN':
                return render_template('admin.html', userinfo = info, productcategory = productcategory, productlist = productlist)
            else:
                return render_template('index.html')
        else:
            return render_template('index.html')
    else:
        return '등록되지 않은 도메인 입니다'

def addp():
    data = {'data': request.form}
    result = data['data']
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"INSERT INTO productlist(name, amount, subtitle, backgroundurl, explanation) VALUES('{result['name']}', '{result['amount']}', '{result['subtitle']}', '{result['subtitle']}', '{result['explanation']}');")
    con.commit()
    con.close()
    return f'{data}'



def buy():
    if 'localhost' in request.base_url :
        if 'username' in session:
            userinfo = database.getuserinfo(session['username'])
            productinfo = database.getproductinfo(request.args.get('item'))
            print(userinfo, productinfo)
            license = getproduct(request.args.get('item'))
            buylog = getbuylog(session['username'])
            if userinfo['money'] > productinfo['amount']:
                addlog(session['username'], license['jaego'])
                deletes(session['username'], license['jaego'])
                database.paymuntitem(userinfo, productinfo)
                return redirect('/buylog')
            else:
                return redirect('/shop')

    else:
        return '등록되지 않은 도메인 입니다'

def buylog():
    if 'localhost' in request.base_url :
        if 'username' in session:
            userinfo = database.getuserinfo(session['username'])
            buylog = getbuylog(session['username'])
            return render_template('buylog.html', userinfo=userinfo, buylog=buylog)

    else:
        return '등록되지 않은 도메인 입니다'
