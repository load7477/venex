import pymysql 

def subdmoain(sitename):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute("SELECT * FROM jaego where name = %s", (sitename))
    return cur.fetchall()