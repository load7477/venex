import pymysql 

def getbuylog(name):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute("SELECT * FROM buylog where name = %s", (name))
    return cur.fetchall()

def addbuylog(name, log):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"INSERT INTO buylog(name, log) VALUES('{name}', '{log}');")
    con.commit()
    con.close()