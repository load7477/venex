import pymysql 
from utils.database import addlog

def getproduct(name):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute("SELECT * FROM jaego where name = %s", (name))
    return cur.fetchone()

def JAEGOCOUNT(name):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    result = cur.execute("SELECT * FROM jaego where name = %s", (name))
    return result

def deletes(name, lis):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"delete from jaego where jaego='"+lis+"';")
    con.commit()
    con.close()
