import pymysql
from flask import Flask,render_template, request, session, redirect, flash


def getuserinfo(ids):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM account WHERE ids='"+str(ids)+"';")
    return cur.fetchone()

def getproductinfo(ids):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM productlist WHERE name='"+str(ids)+"';")
    return cur.fetchone()


def getproductlist():
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM productcategory")
    return cur.fetchall()

def getproductmuch(itemname, username):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM productlist WHERE name='"+str(itemname)+"';")
    s = cur.fetchone()
    ns = getuserinfo(username)
    result = paymuntitem(ns, s)
    return result

def paymuntitem(itemname, userinfo):
    if userinfo['amount'] <= itemname['money']:
        print(itemname['money']-userinfo['amount'])
        con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
        cur = con.cursor() 
        cur.execute(f"UPDATE account SET money={itemname['money']-userinfo['amount']} WHERE ids='{itemname['ids']}';") 
        con.commit()
        cur.execute(f"UPDATE account SET accumulation={str(itemname['accumulation'] + userinfo['amount'])} WHERE ids='{itemname['ids']}';") 
        con.commit()
        con.close()
        return True
    elif userinfo['amount'] >= itemname['money']:
        return False
    else:
        return False

def tosssuccess(amount, id):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor() 
    id=session["username"]
    cur.execute(f"UPDATE account SET money={amount} WHERE ids='{id}';") 
    con.commit()
    con.close()
    print(amount, id)
    return True


def addlog(name, license):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"INSERT INTO buylog(name, log) VALUES('{name}', '{license}');")
    con.commit()
    con.close()
