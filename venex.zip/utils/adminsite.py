import pymysql

def getalluserinfo():
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM account")
    return cur.fetchall()

def getproductcategory():
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM productcategory")
    return cur.fetchall()

def getproductlist():
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM productlist")
    return cur.fetchall()