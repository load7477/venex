import pymysql 

def get():
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM productcategory")
    return cur.fetchall()

def getproduct(subtitle):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='venex', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    result = cur.execute("SELECT * FROM productlist where subtitle = %s", (subtitle))
   
    return cur.fetchall()

def start():
    category = get()
    for c in category:
        c = c['classname']
        s =  getproduct(c)
        return s

