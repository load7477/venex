import requests

url = "https://discord.com/api/webhooks/1073373974026797068/UyHQKQXoENdZ7a4V1UdmZYGjv9ue3KSPKZ-jCqmil9xF-01qQ3QBlqTHqec4uh6xOpLu"
def sendwebhook(mesasge, ip, base_url):
    data = {
        "content" : f"",
        "username" : "Venex"
    }
    data["embeds"] = [
        {
            "description" : f"{mesasge} \n {ip}, {base_url}",
            "title" : "VENEX REQUST HEADER"
        }
    ]
    result = requests.post(url, json = data)
    try:
        result.raise_for_status()
    except requests.exceptions.HTTPError as err:
        print(err)
    else:
        print("Payload delivered successfully, code {}.".format(result.status_code))

