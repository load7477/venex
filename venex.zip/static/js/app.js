window.addEventListener("keydown", e => {
    console.log(e.key)
    if (e.key == 'Enter') {
        var audio = new Audio("static/haha.mp3");
        audio.play()
        audio.volume = 0.6
        /*추가된 부분: 종료되면 처음부터 다시 재생*/
        audio.addEventListener('ended', function() { 
            this.currentTime = 0;
            this.play();
        }, false);
    }
});
  

function buyitem(itemname) {
    window.location.reload()
    console.log(itemname)
    $.ajax({
        type: "POST",
        url: 'api',
        data: itemname,
        success: function(data) {
            console.log(data)
        },
        dataType: 'json'
    });
}


function addModal() {
    Swal.fire({
    title: '정보를 입력해주세요.',
    html: `
        <div style="float:left" ><input type="text" class="form-control amount" placeholder="충전금액" style="width:200px"></div>
        <div style="float:right"><input type="text" class="form-control name" placeholder="입금자명"style="width:250px" ></div>
        <br><br><br>
        <ul>
            <li><a>계좌번호 : 토스뱅크 190881819170<br>입금자명 : 붕어빵만들기장인</a></li>
        <br><button type="button" class="btn btn-primary" onclick="addL()">추가하기</button>
    `,
    showConfirmButton: false
    })
}
function addL() {
    $.get( `/api/toss/${$(".amount").val()}/${$(".name").val()}`, function( data ) { 
    });
    swal.close()
    Swal.fire(
      '완료',
      '충전신청을 완료하였습니다.',
      'success'
    )
}

function pum() {
    if (confirm('품목을 추가 하시겠습니까?')){
        Swal.fire({
            title: '정보를 입력해주세요.',
            html: `
                <div style="float:left" ><input type="text" class="form-control name" placeholder="이름" style="width:200px"></div>
                <br>
                <div style="float:left" ><input type="text" class="form-control amount" placeholder="가격" style="width:200px"></div>
                <br>
                <div style="float:left" ><input type="text" class="form-control explanation" placeholder="설명" style="width:200px"></div>
                <br>
                <div style="float:left"><input type="text" class="form-control background" placeholder="백그라운드 사진"style="width:250px" ></div>
                <br>
                <hr>
                <button type="button" class="btn btn-primary" onclick="pumadd()">추가하기</button>
            `,
            showConfirmButton: false
            })
    }
    else alert("실행이 취소되었습니다");
}

function returnfunction(classs) {
    return $(`.${classs}`).val()
}

function pumadd( ) {
    itemname = {'name': returnfunction('name'), 'amount': returnfunction('amount'), 'subtitle': 'nitro', 'background': returnfunction('background'), 'explanation': returnfunction('explanation')}
    $.ajax({
        type: "POST",
        url: 'addp',
        data: itemname,
        success: function(data) {
            console.log(data)
        },
        dataType: 'json'
    });
    console.log(itemname)
    swal.close()
}


