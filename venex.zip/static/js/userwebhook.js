function sendMessage(Webhook, contents) {
  var request = new XMLHttpRequest();
  request.open("POST", Webhook);

  request.setRequestHeader('Content-type', 'application/json');

  var params = {
    username: "Venex Buylog",
    avatar_url: "https://media.discordapp.net/attachments/1011182058732802069/1074458578687111268/image.png?width=1213&height=682",
    content: `@everyone \n > 구매 해주셔서 감사합니다. \n> ${contents}`
    // Username and content are required to be set, avatar_url isn't. Insert a direct link to an image to use the avatar_url. 
  }
  request.send(JSON.stringify(params));
}