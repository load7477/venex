from flask import Flask, request, session
import route_function
import pymysql
from datetime import timedelta
import time
now = time.strftime("%Y-%m-%d", time.gmtime())

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

app.add_url_rule("/","index",route_function.main) # main site
app.add_url_rule("/shop","shop",route_function.shop) # shop site
app.add_url_rule("/despoit","despoit",route_function.despoit) # despoit site
app.add_url_rule("/login","login",route_function.login) # login site
app.add_url_rule("/login_check", "login_check",route_function.api_login, methods = ['POST', 'GET'])
app.add_url_rule("/register","register",route_function.login) # register site
app.add_url_rule("/api/toss/<amount>/<name>","apitoss", route_function.apitoss) # register site
app.add_url_rule("/logout", "logout", route_function.logout)
app.add_url_rule("/admin", "admin", route_function.admin)
app.add_url_rule("/addp", "addp", route_function.addp, methods=['POST'])
app.add_url_rule("/buy", "buy", route_function.buy, methods=['GET', 'POST'])
app.add_url_rule("/buylog", "buylog", route_function.buylog, methods=['GET', 'POST'])

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=60)

if __name__ == '__main__':
    app.run(host="0.0.0.0",port=80)